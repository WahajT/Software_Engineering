#include <iostream>
using namespace std;

class Grapes : public Fruit
{
    void taste()
    {
        cout << "I'm Grapes and my taste is sweet" << endl;
    }
};
