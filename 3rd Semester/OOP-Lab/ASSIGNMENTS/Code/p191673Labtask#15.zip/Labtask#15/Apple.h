#include <iostream>
using namespace std;

class Apple : public Fruit
{
    void taste()
    {
        cout << "I'm Apple and my taste is sweet" << endl;
    }
};
